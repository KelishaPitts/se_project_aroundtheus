# Project 5: Around The U.S.

# Fuction
Responsive Image gallery with mobile and tablet versions.
Add new cards by inputing a link and description into form.
Delete cards with card remove button.
Change profile name with form input.
Click on image to display image popup.  


# Technology 
View Images in a dynamic photo gallery.
Javascript, flexboxes and grids.  

# Git Pages
https://kelishapitts.github.io/se_project_aroundtheus/
